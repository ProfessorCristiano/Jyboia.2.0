"""
Tabela de palavras-chave, operadores e funções embutidas do Português Estruturado (Jybóia).
"""

from typing import Dict, Set

PALAVRAS_CHAVE: Dict[str, str] = {
    # Controle de Fluxo Condicional
    "se": "if",
    "senaose": "elif",
    "senãose": "elif",
    "senao_se": "elif",
    "senão_se": "elif",
    "senao": "else",
    "senão": "else",
    
    # Laços de Repetição
    "enquanto": "while",
    "para": "for",
    "em": "in",
    "retorne": "return",
    "retorna": "return",
    "pare": "break",
    "interrompa": "break",
    "continue": "continue",
    "proximo": "continue",
    "próximo": "continue",
    "passe": "pass",
    
    # Declarações e Definições
    "funcao": "def",
    "função": "def",
    "defina": "def",
    "metodo": "def",
    "método": "def",
    "classe": "class",
    "global": "global",
    "nao_local": "nonlocal",
    "não_local": "nonlocal",
    "anonima": "lambda",
    "anônima": "lambda",
    "lambda": "lambda",
    
    # Valores e Constantes
    "Verdadeiro": "True",
    "Falso": "False",
    "Nulo": "None",
    "Vazio": "None",
    
    # Operadores Lógicos e de Identidade
    "e": "and",
    "ou": "or",
    "nao": "not",
    "não": "not",
    "eh": "is",
    "é": "is",
    
    # Tratamento de Exceções
    "tente": "try",
    "exceto": "except",
    "trate": "except",
    "finalmente": "finally",
    "lance": "raise",
    "dispare": "raise",
    "afirme": "assert",
    "assegure": "assert",
    
    # Módulos e Contexto
    "importe": "import",
    "importar": "import",
    "de": "from",
    "como": "as",
    "com": "with",
    "produza": "yield",
    "gere": "yield",
    "assincrono": "async",
    "assíncrono": "async",
    "aguarde": "await",
}

PALAVRAS_COMPOSTAS: Dict[tuple, str] = {
    ("senao", "se"): "elif",
    ("senão", "se"): "elif",
    ("nao", "em"): "not in",
    ("não", "em"): "not in",
    ("eh", "nao"): "is not",
    ("é", "nao"): "is not",
    ("eh", "não"): "is not",
    ("é", "não"): "is not",
}

FUNCOES_EMBUTIDAS: Dict[str, str] = {
    # Saída e Entrada
    "escreva": "print",
    "escrever": "print",
    "imprima": "print",
    "imprimir": "print",
    "mostrar": "print",
    "mostre": "print",
    "leia": "input",
    "ler": "input",
    "leia_texto": "input",
    "leia_inteiro": "leia_inteiro",
    "leia_real": "leia_real",
    "leia_int": "leia_int",
    "leia_float": "leia_float",

    # Tipos e Conversão
    "inteiro": "int",
    "real": "float",
    "texto": "str",
    "booleano": "bool",
    "tipo": "type",

    # Coleções
    "lista": "list",
    "dicionario": "dict",
    "dicionário": "dict",
    "conjunto": "set",
    "tupla": "tuple",

    # Funções Gerais
    "intervalo": "range",
    "tamanho": "len",
    "comprimento": "len",
    "soma": "sum",
    "somatorio": "sum",
    "somatório": "sum",
    "minimo": "min",
    "mínimo": "min",
    "maximo": "max",
    "máximo": "max",
    "absoluto": "abs",
    "arredonde": "round",
    "ajuda": "help",
    "ordene": "sorted",
    "ordenado": "sorted",
    "invertido": "reversed",
    "enumerar": "enumerate",
    "enumere": "enumerate",
    "abrir": "open",
    "apague": "del",

    # Funções de Listas (como funções standalone)
    "adicionar": "append",
    "anexar": "append",
    "inserir": "insert",
    "remover_lista": "remove",
    "desempilhar": "pop",
    "limpar_lista": "clear",
    "indice_lista": "index",
    "contar_lista": "count",
    "ordenar_lista": "sort",
    "copiar_lista": "copy",
    "estender": "extend",

    # Funções de Dicionários (como funções standalone)
    "chaves": "keys",
    "valores": "values",
    "itens": "items",
    "obter": "get",
    "atualizar_dict": "update",
    "limpar_dict": "clear",
    "copiar_dict": "copy",
    "chaves_dict": "keys",
    "valores_dict": "values",
    "itens_dict": "items",

    # Funções de Strings
    "dividir": "split",
    "juntar": "join",
    "substituir": "replace",
    "maiusculas": "upper",
    "minusculas": "lower",
    "aparar": "strip",
    "comeca_com": "startswith",
    "termina_com": "endswith",
    "encontrar": "find",
    "contar_str": "count",
    "formatar": "format",

    # Funções Matemáticas
    "potencia": "pow",
    "arredondar": "round",
    "abs": "abs",

    # Funções de Arquivo
    "leia_arquivo": "read",
    "leia_linha": "readline",
    "leia_linhas": "readlines",
    "escreva_arquivo": "write",
    "escreva_linhas": "writelines",
}

TODAS_PALAVRAS_RESERVADAS: Set[str] = (
    set(PALAVRAS_CHAVE.keys())
    | set(FUNCOES_EMBUTIDAS.keys())
    | {
        "senao se", "senão se", "não em", "nao em", "é não", "eh não",
        "leia_inteiro", "leia_real", "leia_int", "leia_float",
        "adicionar", "anexar", "inserir", "remover_lista", "desempilhar",
        "limpar_lista", "indice_lista", "contar_lista", "ordenar_lista",
        "copiar_lista", "estender", "chaves", "valores", "itens", "obter",
        "atualizar_dict", "limpar_dict", "copiar_dict", "chaves_dict",
        "valores_dict", "itens_dict", "dividir", "juntar", "substituir",
        "maiusculas", "minusculas", "aparar", "comeca_com", "termina_com",
        "encontrar", "contar_str", "formatar", "potencia", "arredondar",
        "leia_arquivo", "leia_linha", "leia_linhas", "escreva_arquivo",
        "escreva_linhas", "apague",
    }
)
